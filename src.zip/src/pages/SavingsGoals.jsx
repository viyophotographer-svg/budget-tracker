import React, { useState, useEffect } from 'react';
import { Plus, Target, TrendingUp, Trash2, Edit2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export default function SavingsGoals() {
  const { user } = useAuth();
  const [goals, setGoals] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    goal_name: '',
    target_amount: '',
    saved_amount: '',
    deadline: '',
  });

  useEffect(() => {
    // Mock data - replace with actual API call
    const mockGoals = [
      {
        id: 1,
        goal_name: 'New Camera Fund',
        target_amount: 100000,
        saved_amount: 25000,
        deadline: '2025-12-31',
      },
      {
        id: 2,
        goal_name: 'Vacation',
        target_amount: 200000,
        saved_amount: 80000,
        deadline: '2025-06-30',
      },
      {
        id: 3,
        goal_name: 'Emergency Fund',
        target_amount: 500000,
        saved_amount: 150000,
        deadline: '2026-12-31',
      },
    ];
    setGoals(mockGoals);
  }, [user]);

  const handleAddGoal = (e) => {
    e.preventDefault();
    const newGoal = {
      id: goals.length + 1,
      ...formData,
      target_amount: parseFloat(formData.target_amount),
      saved_amount: parseFloat(formData.saved_amount || 0),
    };
    setGoals([...goals, newGoal]);
    setFormData({ goal_name: '', target_amount: '', saved_amount: '', deadline: '' });
    setShowForm(false);
  };

  const deleteGoal = (id) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Savings Goals</h1>
        <p className="text-slate-400">Track your financial goals and milestones</p>
      </div>

      {/* Add Goal Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
      >
        <Plus className="w-5 h-5" />
        Create New Goal
      </button>

      {/* Add Goal Form */}
      {showForm && (
        <form onSubmit={handleAddGoal} className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 backdrop-blur-xl border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">Create New Savings Goal</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Goal Name (e.g., Vacation)"
              value={formData.goal_name}
              onChange={(e) => setFormData({ ...formData, goal_name: e.target.value })}
              className="bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              required
            />
            <input
              type="number"
              placeholder="Target Amount"
              value={formData.target_amount}
              onChange={(e) => setFormData({ ...formData, target_amount: e.target.value })}
              className="bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              required
            />
            <input
              type="number"
              placeholder="Current Saved Amount"
              value={formData.saved_amount}
              onChange={(e) => setFormData({ ...formData, saved_amount: e.target.value })}
              className="bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
            <input
              type="date"
              value={formData.deadline}
              onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
              className="bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500"
              required
            />
            <button
              type="submit"
              className="md:col-span-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-6 py-2 font-medium transition"
            >
              Create Goal
            </button>
          </div>
        </form>
      )}

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((goal) => {
          const progress = (goal.saved_amount / goal.target_amount) * 100;
          const daysLeft = Math.ceil((new Date(goal.deadline) - new Date()) / (1000 * 60 * 60 * 24));

          return (
            <div key={goal.id} className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 backdrop-blur-xl border border-slate-700 hover:border-blue-600/50 transition">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-blue-600/20 rounded-lg">
                    <Target className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{goal.goal_name}</h3>
                    <p className="text-xs text-slate-400">{daysLeft} days left</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-slate-700 rounded-lg transition text-slate-300">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteGoal(goal.id)}
                    className="p-2 hover:bg-red-900/20 rounded-lg transition text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-slate-300">Progress</span>
                  <span className="text-sm font-bold text-blue-400">{progress.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-500"
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Amount Info */}
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-slate-400">Saved</span>
                  <span className="text-white font-bold">₹{goal.saved_amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Target</span>
                  <span className="text-white font-bold">₹{goal.target_amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Remaining</span>
                  <span className="text-emerald-400 font-bold">
                    ₹{(goal.target_amount - goal.saved_amount).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Add Funds Button */}
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2 font-medium transition flex items-center justify-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Add Funds
              </button>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {goals.length === 0 && !showForm && (
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-12 text-center backdrop-blur-xl border border-slate-700">
          <Target className="w-12 h-12 text-slate-400 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-semibold text-white mb-2">No Savings Goals</h3>
          <p className="text-slate-400 mb-6">Create your first savings goal to start tracking your financial milestones</p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
          >
            <Plus className="w-5 h-5" />
            Create Goal
          </button>
        </div>
      )}
    </div>
  );
}