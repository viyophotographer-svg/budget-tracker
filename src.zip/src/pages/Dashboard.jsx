import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Target, Wallet, Plus } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import BudgetProgress from '../components/BudgetProgress';
import StatCard from '../components/StatCard';

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalBalance: 0,
    totalIncome: 0,
    totalExpenses: 0,
    savingsGoals: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    // Simulated data - replace with actual API calls
    const mockStats = {
      totalBalance: 125000,
      totalIncome: 250000,
      totalExpenses: 125000,
      savingsGoals: 3,
    };

    setTimeout(() => {
      setStats(mockStats);
      setLoading(false);
    }, 500);
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Welcome back, {user?.email?.split('@')[0]}! 👋</h1>
        <p className="text-slate-400">Here's your financial overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Balance"
          value={`₹${stats.totalBalance.toLocaleString()}`}
          icon={Wallet}
          color="blue"
          change="+12.5%"
        />
        <StatCard
          title="Total Income"
          value={`₹${stats.totalIncome.toLocaleString()}`}
          icon={TrendingUp}
          color="green"
          change="+8.2%"
        />
        <StatCard
          title="Total Expenses"
          value={`₹${stats.totalExpenses.toLocaleString()}`}
          icon={TrendingDown}
          color="red"
          change="-5.3%"
        />
        <StatCard
          title="Savings Goals"
          value={stats.savingsGoals}
          icon={Target}
          color="purple"
          change="Active"
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Budget Progress */}
        <div className="lg:col-span-2">
          <BudgetProgress />
        </div>

        {/* Quick Actions */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 backdrop-blur-xl border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full flex items-center gap-3 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
              <Plus className="w-5 h-5" />
              Add Transaction
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition font-medium">
              <Target className="w-5 h-5" />
              New Savings Goal
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition font-medium">
              <Wallet className="w-5 h-5" />
              View Budget
            </button>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 backdrop-blur-xl border border-slate-700">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Recent Transactions</h3>
          <a href="/transactions" className="text-blue-400 hover:text-blue-300 text-sm font-medium">
            View All →
          </a>
        </div>

        <div className="space-y-3">
          {[
            { title: 'Grocery Shopping', amount: 1200, type: 'expense', date: 'Today' },
            { title: 'Freelance Income', amount: 5000, type: 'income', date: 'Yesterday' },
            { title: 'Electricity Bill', amount: 800, type: 'expense', date: '2 days ago' },
            { title: 'Salary', amount: 50000, type: 'income', date: '5 days ago' },
          ].map((trans, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition">
              <div>
                <p className="text-white font-medium">{trans.title}</p>
                <p className="text-xs text-slate-400">{trans.date}</p>
              </div>
              <p className={`font-bold ${trans.type === 'income' ? 'text-green-400' : 'text-red-400'}`}>
                {trans.type === 'income' ? '+' : '-'}₹{trans.amount.toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}