import React, { useState, useEffect } from 'react';
import { User, Mail, Globe, Moon, Save, LogOut } from 'lucide-react';
import { getUserProfile, updateUserProfile } from '../services/authService';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    currency: 'INR',
    darkMode: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    if (!user) return;

    const fetchProfile = async () => {
      try {
        setLoading(true);
        const profileData = await getUserProfile(user.id);
        if (profileData) {
          setProfile(profileData);
          setFormData({
            name: profileData.name || '',
            email: profileData.email || user.email || '',
            currency: profileData.currency || 'INR',
            darkMode: profileData.darkMode !== false,
          });
        } else {
          setFormData(prev => ({
            ...prev,
            email: user.email || '',
          }));
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        setFormData(prev => ({
          ...prev,
          email: user.email || '',
        }));
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    if (!user) return;

    try {
      setSaving(true);
      setMessage(null);

      await updateUserProfile(user.id, {
        name: formData.name,
        email: formData.email,
        currency: formData.currency,
        darkMode: formData.darkMode,
      });

      setMessage({ type: 'success', text: 'Profile updated successfully!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (err) {
      setMessage({ type: 'error', text: err.message || 'Failed to update profile' });
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (err) {
      console.error('Error logging out:', err);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="bg-slate-800 rounded-2xl h-96"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <User className="w-8 h-8 text-blue-400" />
          <h1 className="text-3xl font-bold text-white">Profile Settings</h1>
        </div>
        <p className="text-slate-400">Manage your account and preferences</p>
      </div>

      {/* Messages */}
      {message && (
        <div className={`rounded-2xl p-4 backdrop-blur-xl border ${
          message.type === 'success' 
            ? 'bg-green-900/20 border-green-700/50 text-green-400' 
            : 'bg-red-900/20 border-red-700/50 text-red-400'
        }`}>
          {message.text}
        </div>
      )}

      {/* Profile Form */}
      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Profile Card */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 backdrop-blur-xl border border-slate-700">
          <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
            <User className="w-5 h-5 text-blue-400" />
            Personal Information
          </h2>

          <div className="space-y-5">
            {/* Name Field */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Full Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter your full name"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition"
              />
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                disabled
                className="w-full bg-slate-700/30 border border-slate-600 rounded-lg px-4 py-3 text-slate-400 cursor-not-allowed opacity-60"
              />
              <p className="text-xs text-slate-400 mt-1">Email cannot be changed</p>
            </div>
          </div>
        </div>

        {/* Preferences Card */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 backdrop-blur-xl border border-slate-700">
          <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
            <Globe className="w-5 h-5 text-emerald-400" />
            Preferences
          </h2>

          <div className="space-y-5">
            {/* Currency Selection */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Currency
              </label>
              <select
                name="currency"
                value={formData.currency}
                onChange={handleInputChange}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition"
              >
                <option value="INR">Indian Rupee (₹)</option>
                <option value="USD">US Dollar ($)</option>
                <option value="EUR">Euro (€)</option>
                <option value="GBP">British Pound (£)</option>
              </select>
            </div>

            {/* Dark Mode Toggle */}
            <div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="darkMode"
                  checked={formData.darkMode}
                  onChange={handleInputChange}
                  className="w-5 h-5 rounded bg-slate-700/50 border border-slate-600 cursor-pointer accent-blue-500"
                />
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-slate-300" />
                  <span className="text-slate-300">Enable Dark Mode</span>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-lg transition-all flex items-center justify-center gap-2"
          >
            <Save className="w-5 h-5" />
            {saving ? 'Saving...' : 'Save Changes'}
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="flex-1 bg-gradient-to-r from-red-600/20 to-red-700/20 hover:from-red-600/30 hover:to-red-700/30 border border-red-600/30 hover:border-red-600 text-red-400 font-semibold py-3 rounded-lg transition-all flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </form>

      {/* Account Info */}
      <div className="bg-slate-700/30 border border-slate-600 rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-slate-300 mb-3">Account Information</h3>
        <div className="space-y-2 text-sm text-slate-400">
          <p>User ID: <span className="text-slate-300 font-mono">{user?.id?.substring(0, 12)}...</span></p>
          <p>Account Type: <span className="text-slate-300">Free User</span></p>
          {profile?.created_at && (
            <p>Member Since: <span className="text-slate-300">{new Date(profile.created_at).toLocaleDateString()}</span></p>
          )}
        </div>
      </div>
    </div>
  );
}
