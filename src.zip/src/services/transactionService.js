import { supabase } from "../supabase";

export const getTransactions = async (userId, limit = 50, offset = 0) => {
  const { data, error, count } = await supabase
    .from("transactions")
    .select("*", { count: "exact" })
    .eq("user_id", userId)
    .order("transaction_date", { ascending: false })
    .range(offset, offset + limit - 1);

  if (error) throw error;

  return { data, count };
};

export const createTransaction = async (userId, transaction) => {
  const { data, error } = await supabase
    .from("transactions")
    .insert([
      {
        user_id: userId,
        amount: transaction.amount,
        category: transaction.category,
        type: transaction.type,
        transaction_date: transaction.transaction_date,
        notes: transaction.notes,
      },
    ])
    .select()
    .single();

  if (error) throw error;

  return data;
};

export const updateTransaction = async (transactionId, updates) => {
  const { data, error } = await supabase
    .from("transactions")
    .update(updates)
    .eq("id", transactionId)
    .select()
    .single();

  if (error) throw error;

  return data;
};

export const deleteTransaction = async (transactionId) => {
  const { error } = await supabase
    .from("transactions")
    .delete()
    .eq("id", transactionId);

  if (error) throw error;
};

export const getTotalExpenses = async (userId) => {
  const { data, error } = await supabase
    .from("transactions")
    .select("amount")
    .eq("user_id", userId)
    .eq("type", "expense");

  if (error) throw error;

  return data.reduce((sum, item) => sum + Number(item.amount), 0);
};

export const getTotalIncome = async (userId) => {
  const { data, error } = await supabase
    .from("transactions")
    .select("amount")
    .eq("user_id", userId)
    .eq("type", "income");

  if (error) throw error;

  return data.reduce((sum, item) => sum + Number(item.amount), 0);
};