import { supabase } from '../supabase';

export const getAnalytics = async (userId) => {
  try {
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (error) throw error;

    const categoryMap = {};
    const monthlyMap = {};

    transactions?.forEach(transaction => {
      if (!categoryMap[transaction.category]) {
        categoryMap[transaction.category] = 0;
      }

      if (transaction.type === 'expense') {
        categoryMap[transaction.category] += transaction.amount || 0;
      }

      const monthKey = new Date(transaction.date).toLocaleString('default', { month: 'short', year: 'numeric' });
      if (!monthlyMap[monthKey]) {
        monthlyMap[monthKey] = { income: 0, expense: 0, month: monthKey };
      }

      if (transaction.type === 'income') {
        monthlyMap[monthKey].income += transaction.amount || 0;
      } else {
        monthlyMap[monthKey].expense += transaction.amount || 0;
      }
    });

    const categoryData = Object.entries(categoryMap).map(([name, value]) => ({
      name,
      value,
    }));

    const monthlyData = Object.values(monthlyMap).sort((a, b) => {
      const dateA = new Date(a.month);
      const dateB = new Date(b.month);
      return dateA - dateB;
    });

    return {
      categoryData,
      monthlyData,
    };
  } catch (error) {
    console.error('Error fetching analytics:', error);
    throw error;
  }
};